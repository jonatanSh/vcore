class Asset(object):
    def __init__(self, requests, api):
        self.requests = requests
        self.api = api
